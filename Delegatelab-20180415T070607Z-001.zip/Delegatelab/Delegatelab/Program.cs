﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegatelab
{
    class Program
    {
        public delegate void myDel1(double a, double b);
        static void Main(string[] args)
        {
            BasicCalc obj = new BasicCalc();
            myDel1 md = null;

            md += obj.add;
            md += obj.sub;
            md += obj.mul;
            md += obj.div;
            md(20, 5);
        }
    }
}
