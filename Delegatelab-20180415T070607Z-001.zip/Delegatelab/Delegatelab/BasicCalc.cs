﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegatelab
{
    class BasicCalc
    {
        public void add(double a, double b)
        {
            Console.WriteLine("Add: " + (a + b));
        }
        public void sub(double a, double b)
        {
            Console.WriteLine("Sub: " + (a - b));
        }
        public void mul(double a, double b)
        {
            Console.WriteLine("Mul: " + (a * b));
        }
        public void div(double a, double b)
        {
            Console.WriteLine("Div: " + (a / b));
        }

    }
}
